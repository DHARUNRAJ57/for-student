<?php 

include("database.php");


$meeting_cancel = [];
$sql1 = "SELECT whatsapp_no from user_master where category ='OB'";

if ($result = mysqli_query($mysqli, $sql1)) {
    $cr = 0;
    while ($row = mysqli_fetch_assoc($result)) {
   
        $meeting_cancel[$cr]['whatsapp_no'] = $row['whatsapp_no'];
        // $meeting_cancel[$cr]['time'] = $row['time'];
        // $meeting_cancel[$cr]['meeting_name'] = $row['meeting_name'];
        // $meeting_cancel[$cr]['meeting_location'] = $row['meeting_location'];
        // $meeting_cancel[$cr]['meeting_type'] = $row['meeting_type'];
        // $meeting_cancel[$cr]['participants'] = $row['participants'];
        // $meeting_cancel[$cr]['constituency'] = $row['constituency'];
        // $show_user[$cr]['meeting_name'] = $row['meeting_name'];
    //  $show_user[$cr]['mode'] = $row['mode'];
    //  $show_user[$cr]['email'] = $row['email'];


    echo json_encode(['data' =>  $meeting_cancel]);
    }
}

?>