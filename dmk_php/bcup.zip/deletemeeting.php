<?php

include "database.php";
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);

$user_id = $request->id;

$sql = "UPDATE meetings SET status='cancel' WHERE id= $user_id";

if ($mysqli->query($sql) === true) {
    // echo json_encode(" Record updated successfully");
    $meeting_cancel = [];

    $sql1 = "SELECT date,time,meeting_name,meeting_location,meeting_type,participants,constituency,description FROM meetings WHERE id=$user_id";
    echo $sql1;
    if ($result = mysqli_query($mysqli, $sql1)) {
        $cr = 0;
        while ($row = mysqli_fetch_assoc($result)) {

            $meeting_cancel[$cr]['date'] = $row['date'];
            $meeting_cancel[$cr]['time'] = $row['time'];
            $meeting_cancel[$cr]['meeting_name'] = $row['meeting_name'];
            $meeting_cancel[$cr]['meeting_location'] = $row['meeting_location'];
            $meeting_cancel[$cr]['meeting_type'] = $row['meeting_type'];
            $meeting_cancel[$cr]['participants'] = $row['participants'];
            $meeting_cancel[$cr]['constituency'] = $row['constituency'];
        }
        echo json_encode($meeting_cancel);
    }
        $user_email = [];
        if ($meeting_cancel[$cr]['participants'] == 3) {

            $sql = "SELECT whatsapp_no from user_master where category ='OB'";
            if ($result = mysqli_query($mysqli, $sql)) {
                $cr = 0;
                while ($row = mysqli_fetch_assoc($result)) {
                    $user_email[$cr]['whatsapp_no'] = $row['whatsapp_no'];
                    whatsapp($user_email[$cr]['whatsapp_no'], $meeting_cancel[$cr]['meeting_name'], $meeting_cancel[$cr]['time'], $meeting_cancel[$cr]['meeting_location'], $meeting_cancel[$cr]['meeting_type']);
                    $cr++;
                }
            }
        }
    }
 else {
    echo json_encode("Error delete record: " . $mysqli->connect_error);
}

function whatsapp($whatsapp_no, $meeting_name, $date, $location, $type)
{
    $meet_type = $type;
    if ($meet_type == "offline") {
        $curl = curl_init();
        curl_setopt_array(
            $curl,
            array(
                CURLOPT_URL => 'https://graph.facebook.com/v15.0/115641688109792/messages',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => json_encode(
                    array(
                        'messaging_product' => "whatsapp",
                        'recipient_type' => "individual",
                        'to' => "91".$whatsapp_no."",
                        'type' => "template",

                        'template' => array(
                            'name' => "offline_meeting",
                            'language' => array(
                                'code' => "en_US",
                            ),
                            'components' => array(
                                array(
                                    'type' => "body",
                                    'parameters' => array(
                                        array(
                                            'type' => "text",
                                            'text' => $meeting_name,
                                        ),
                                        array(
                                            'type' => "text",
                                            'text' => $location,
                                        ),
                                        array(
                                            'type' => "text",
                                            'text' => $date,
                                        ),
                                        // array(
                                        //     'type'=>"text",
                                        //     'text'=>'ragasudha',
                                        // ),
                                    ),
                                ),
                            ),
                        ),
                    )
                ),
                CURLOPT_HTTPHEADER => array(
                    'Authorization: Bearer EAAHROdmfOsUBADMW76O5ORtgWiNfWSsZBOKqxF6qtgmYyMBE9vcsc1fUCzF2eMRfDwpLp9v82CjxQfcvFo8jRunWC3IXhkP1dFhYl83x9smVBmvjfXgDEoZC6cw4UYLL5esjxZBIm5cSq1tpDOLIPYCP24nNoBNth3qvFPrUAOe5H44zZBIZAZAO1zD8E8ttmzbgypejNioQZDZD',
                    'Content-Type: application/json',
                ),
            )
        );
        $response = curl_exec($curl);
        curl_close($curl);
    } else {
        $curl = curl_init();
        curl_setopt_array(
            $curl,
            array(
                CURLOPT_URL => 'https://graph.facebook.com/v15.0/115641688109792/messages',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => json_encode(
                    array(
                        'messaging_product' => "whatsapp",
                        'recipient_type' => "individual",
                        'to' => '918608053937',
                        'type' => "template",

                        'template' => array(
                            'name' => "eng_meeting",
                            'language' => array(
                                'code' => "en_US",
                            ),
                            'components' => array(
                                array(
                                    'type' => "body",
                                    'parameters' => array(
                                        array(
                                            'type' => "text",
                                            'text' => $date,
                                        ),
                                        array(
                                            'type' => "text",
                                            'text' => $location,
                                        ),
                                        // array(
                                        //     'type' => "text",
                                        //     'text' => $location,
                                        // ),
                                        // array(
                                        //     'type'=>"text",
                                        //     'text'=>'ragasudha',
                                        // ),
                                    ),
                                ),
                            ),
                        ),
                    )
                ),
                CURLOPT_HTTPHEADER => array(
                    'Authorization: Bearer EAAHROdmfOsUBADMW76O5ORtgWiNfWSsZBOKqxF6qtgmYyMBE9vcsc1fUCzF2eMRfDwpLp9v82CjxQfcvFo8jRunWC3IXhkP1dFhYl83x9smVBmvjfXgDEoZC6cw4UYLL5esjxZBIm5cSq1tpDOLIPYCP24nNoBNth3qvFPrUAOe5H44zZBIZAZAO1zD8E8ttmzbgypejNioQZDZD',
                    'Content-Type: application/json',
                ),
            )
        );
        $response = curl_exec($curl);
        curl_close($curl);
    }
}
